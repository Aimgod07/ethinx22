import { catchAsyncErrors } from "../middlewares/catchingAsyncerrors.js";
import errorHandler from "../middlewares/errorMiddleware.js";


export const patientRegister=catchAsyncErrors(async(req,res,next)=>{
    const {firstName,lastName,email,password,gender,dob,address,phone,nic,
    }=req.body;
    if(!firstName || !lastName || !email || !password || !gender || !dob || !address || !phone || !nic)
        {
        return next(new errorHandler("All fields are required",400));
    }
    const existingUser=await User.findOne({email});
    if(existingUser){
        return next(new errorHandler("User already exists",400));
    }
    const user=await User.create({
        firstName,
        lastName,
        email,
        password,
        gender,
        dob,
        address,
        phone,
        nic,    
    });
    res.status(201).json({
        success:true,
        message:"Patient registered successfully",
        user,
    });
})      

export const login = catchAsyncErrors(async(req,res,next)=>{
    const {email,password,confirmPassword,role}=req.body;
    const existingUser=await User.findOne({email});
    if(!email || !password || !confirmPassword || !role){
        return next(new errorHandler("All fields are required",400));
    }
    if(password !== confirmPassword){
        return next(new errorHandler("Password and confirm password do not match",400));
    }
    if(!existingUser){
        return next(new errorHandler("User not found",400));
    }
    const User=await User.findOne({email}).select("+password")

    if(!existingUser){
        return next(new errorHandler("User not found",400));
    }

    const isPasswordMatch=await bcrypt.compare(password,existingUser.password);
    if(!isPasswordMatch){
        return next(new errorHandler("Invalid password",400));
    }   
    if(role!==user.role){
        return next(new errorHandler("User with the role not found",400));
    }   
    res.status(201).json({
        success:true,
        message:"User logged in successfully",
        user,
    });
})  
